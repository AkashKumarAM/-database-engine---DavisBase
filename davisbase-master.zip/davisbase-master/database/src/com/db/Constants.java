package com.db;

public interface Constants {
	
	
	public static final int PAGESIZE=512;
	

}
