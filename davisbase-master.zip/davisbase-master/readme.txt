Run Davisbase.java
After that:

These are selected commands.
 
 SELECT * FROM table_name; 
 
 SELECT * FROM table_name WHERE rowid = <value>; 
 
 INSERT INTO table_name (column_1,column_2.....) table_name values (<value1>,<value2>.....);
 
 CREATE TABLE table_name (rowid INT PRIMARY KEY, variable TEXT [NULL]); 
 
 UPDATE table_name SET rowid=intvalue WHERE rowid=intvalue;  
 
 DELETE FROM TABLE table_name where rowid=intvalue; 
 
 DROP TABLE table_name;
